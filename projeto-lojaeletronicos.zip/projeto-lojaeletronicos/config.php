<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "loja_eletronicos";

$conn = new mysqli($host, $user, $pass, $db);

if($conn->connect_error){
    die("Erro ao conectar ao banco: " . $conn->connect_error);
}
?>
