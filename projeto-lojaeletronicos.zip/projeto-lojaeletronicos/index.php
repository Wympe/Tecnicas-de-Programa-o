<?php include("config.php"); ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>TechStore - Loja de Eletrônicos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: #f7f7f7;
        }
        nav.navbar {
            background: #1E1E1E;
        }

        /* CORREÇÃO DEFINITIVA DO TEXTO */
        .navbar-dark .navbar-nav .nav-link {
            color: #fff !important;
        }
        .navbar-dark .navbar-brand{
            color: #fff !important;
            font-weight: bold;
        }

        main{
            padding: 30px;
            background: white;
            margin: 20px;
            border-radius: 10px;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-dark bg-dark navbar-expand-lg">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php">TechStore</a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav me-auto">

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
            Produtos
          </a>
          <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="?page=produtos-cadastrar">Cadastrar</a></li>
              <li><a class="dropdown-item" href="?page=produtos-listar">Listar</a></li>
          </ul>
        </li>

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
            Clientes
          </a>
          <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="?page=clientes-cadastrar">Cadastrar</a></li>
              <li><a class="dropdown-item" href="?page=clientes-listar">Listar</a></li>
          </ul>
        </li>

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
            Marcas
          </a>
          <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="?page=marcas-cadastrar">Cadastrar</a></li>
              <li><a class="dropdown-item" href="?page=marcas-listar">Listar</a></li>
          </ul>
        </li>

      </ul>
    </div>
  </div>
</nav>

<main>
<?php
    if(isset($_GET["page"])){
        include("pages/" . $_GET["page"] . ".php");
    } else {
        echo "<h1>Bem-vindo ao sistema da TechStore</h1>";
    }
?>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
