<?php
switch($_POST["acao"]){

    case "cadastrar":
        $sql = "INSERT INTO clientes (nome, email, telefone)
                VALUES ('{$_POST["nome"]}', '{$_POST["email"]}', '{$_POST["telefone"]}')";

        $res = $conn->query($sql);

        if($res){
            print "<script>alert('Cliente cadastrado com sucesso!');</script>";
            print "<script>location.href='?page=clientes-listar';</script>";
        } else {
            print "<script>alert('Erro ao cadastrar!');</script>";
        }
    break;

    case "editar":
        $sql = "UPDATE clientes SET
                nome='{$_POST["nome"]}',
                email='{$_POST["email"]}',
                telefone='{$_POST["telefone"]}'
                WHERE id={$_POST["id"]}";

        $res = $conn->query($sql);

        if($res){
            print "<script>alert('Cliente atualizado!');</script>";
            print "<script>location.href='?page=clientes-listar';</script>";
        } else {
            print "<script>alert('Erro ao editar!');</script>";
        }
    break;
}
?>
