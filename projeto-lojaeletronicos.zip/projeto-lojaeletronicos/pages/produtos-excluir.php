<?php
$sql = "DELETE FROM produtos WHERE id=".$_GET["id"];
$res = $conn->query($sql);

if($res){
    print "<script>alert('Produto excluído!');</script>";
    print "<script>location.href='?page=produtos-listar';</script>";
} else {
    print "<script>alert('Erro ao excluir!');</script>";
}
?>
