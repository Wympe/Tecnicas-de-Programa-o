<?php
$sql = "DELETE FROM marcas WHERE id=".$_GET["id"];
$res = $conn->query($sql);

if($res){
    print "<script>alert('Marca removida!');</script>";
    print "<script>location.href='?page=marcas-listar';</script>";
} else {
    print "<script>alert('Erro ao excluir!');</script>";
}
?>
