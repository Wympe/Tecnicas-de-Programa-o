<h2>Cadastrar Marca</h2>

<form action="?page=marcas-salvar" method="POST">
    <input type="hidden" name="acao" value="cadastrar">

    <div class="mb-3">
        <label>Nome da Marca:</label>
        <input type="text" name="nome" class="form-control" required>
    </div>

    <button class="btn btn-success">Salvar</button>
</form>
