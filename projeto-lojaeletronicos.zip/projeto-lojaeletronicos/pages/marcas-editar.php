<?php
$sql = "SELECT * FROM marcas WHERE id=".$_GET["id"];
$res = $conn->query($sql);
$row = $res->fetch_object();
?>

<h2>Editar Marca</h2>

<form action="?page=marcas-salvar" method="POST">
    <input type="hidden" name="acao" value="editar">
    <input type="hidden" name="id" value="<?=$row->id;?>">

    <div class="mb-3">
        <label>Nome da Marca:</label>
        <input type="text" name="nome" class="form-control" value="<?=$row->nome;?>" required>
    </div>

    <button class="btn btn-success">Salvar</button>
</form>
