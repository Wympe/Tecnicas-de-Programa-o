<?php
switch($_POST["acao"]){

    case "cadastrar":
        $sql = "INSERT INTO marcas (nome)
                VALUES ('{$_POST["nome"]}')";

        $res = $conn->query($sql);

        if($res){
            print "<script>alert('Marca cadastrada!');</script>";
            print "<script>location.href='?page=marcas-listar';</script>";
        } else {
            print "<script>alert('Erro ao cadastrar!');</script>";
        }
    break;

    case "editar":
        $sql = "UPDATE marcas SET
                nome='{$_POST["nome"]}'
                WHERE id={$_POST["id"]}";

        $res = $conn->query($sql);

        if($res){
            print "<script>alert('Marca atualizada!');</script>";
            print "<script>location.href='?page=marcas-listar';</script>";
        } else {
            print "<script>alert('Erro ao editar!');</script>";
        }
    break;
}
?>
