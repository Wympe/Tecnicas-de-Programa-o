<h2>Cadastrar Produto</h2>
<form action="?page=produtos-salvar" method="POST">
    <input type="hidden" name="acao" value="cadastrar">

    <div class="mb-3">
        <label>Nome:</label>
        <input type="text" name="nome" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Marca:</label>
        <input type="text" name="marca" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Preço:</label>
        <input type="number" step="0.01" name="preco" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Categoria:</label>
        <input type="text" name="categoria" class="form-control" required>
    </div>

    <button class="btn btn-success">Salvar</button>
</form>
