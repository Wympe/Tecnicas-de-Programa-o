<h2>Lista de Clientes</h2>

<?php
$sql = "SELECT * FROM clientes";
$res = $conn->query($sql);

if($res->num_rows > 0){
    print "<table class='table table-bordered table-striped'>";
    print "<tr>";
    print "<th>ID</th>";
    print "<th>Nome</th>";
    print "<th>Email</th>";
    print "<th>Telefone</th>";
    print "<th>Ações</th>";
    print "</tr>";

    while($row = $res->fetch_object()){
        print "<tr>";
        print "<td>$row->id</td>";
        print "<td>$row->nome</td>";
        print "<td>$row->email</td>";
        print "<td>$row->telefone</td>";
        print "<td>
                <a href='?page=clientes-editar&id=$row->id' class='btn btn-primary btn-sm'>Editar</a>
                <a href='?page=clientes-excluir&id=$row->id' class='btn btn-danger btn-sm'>Excluir</a>
               </td>";
        print "</tr>";
    }

    print "</table>";

} else {
    print "<p>Nenhum cliente cadastrado.</p>";
}
?>
