<?php
$sql = "SELECT * FROM clientes WHERE id=".$_GET["id"];
$res = $conn->query($sql);
$row = $res->fetch_object();
?>

<h2>Editar Cliente</h2>

<form action="?page=clientes-salvar" method="POST">
    <input type="hidden" name="acao" value="editar">
    <input type="hidden" name="id" value="<?=$row->id;?>">

    <div class="mb-3">
        <label>Nome:</label>
        <input type="text" name="nome" class="form-control" value="<?=$row->nome;?>" required>
    </div>

    <div class="mb-3">
        <label>Email:</label>
        <input type="email" name="email" class="form-control" value="<?=$row->email;?>" required>
    </div>

    <div class="mb-3">
        <label>Telefone:</label>
        <input type="text" name="telefone" class="form-control" value="<?=$row->telefone;?>" required>
    </div>

    <button class="btn btn-success">Salvar</button>
</form>
