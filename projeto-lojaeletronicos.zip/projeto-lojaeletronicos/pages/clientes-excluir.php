<?php
$sql = "DELETE FROM clientes WHERE id=".$_GET["id"];
$res = $conn->query($sql);

if($res){
    print "<script>alert('Cliente removido!');</script>";
    print "<script>location.href='?page=clientes-listar';</script>";
} else {
    print "<script>alert('Erro ao excluir!');</script>";
}
?>
