<?php
switch($_POST["acao"]){

    case "cadastrar":
        $sql = "INSERT INTO produtos (nome, marca, preco, categoria)
                VALUES ('{$_POST["nome"]}','{$_POST["marca"]}',
                        '{$_POST["preco"]}','{$_POST["categoria"]}')";

        $res = $conn->query($sql);

        if($res){
            print "<script>alert('Produto cadastrado com sucesso!');</script>";
            print "<script>location.href='?page=produtos-listar';</script>";
        } else {
            print "<script>alert('Erro ao salvar!');</script>";
        }
    break;

    case "editar":
        $sql = "UPDATE produtos SET
                nome='{$_POST["nome"]}',
                marca='{$_POST["marca"]}',
                preco='{$_POST["preco"]}',
                categoria='{$_POST["categoria"]}'
                WHERE id={$_POST["id"]}";

        $res = $conn->query($sql);

        if($res){
            print "<script>alert('Produto editado com sucesso!');</script>";
            print "<script>location.href='?page=produtos-listar';</script>";
        } else {
            print "<script>alert('Erro ao editar!');</script>";
        }
    break;
}
?>
