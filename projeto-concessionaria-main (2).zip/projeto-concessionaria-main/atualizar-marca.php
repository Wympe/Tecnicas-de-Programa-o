<h1>Atualizar Marca</h1>
<?php
require_once("config.php");
$id   = isset($_POST['id_marca']) ? (int)$_POST['id_marca'] : 0;
$nome = $_POST['nome_marca'] ?? '';
if ($id <= 0) {
    echo "<p>ID de marca inválido.</p>";
    exit;
}
$sql = "UPDATE marca SET nome_marca = '$nome' WHERE id_marca = $id";
if ($conn->query($sql)) {
    echo "<p><strong>Marca atualizada com sucesso!</strong></p>";
} else {
    echo "<p><strong>Erro ao atualizar marca:</strong> " . $conn->error . "</p>";
}
echo "<hr>";
echo "<p>Nome da marca: $nome</p>";
echo "<p><a href='index.php?page=listar-marca'>Voltar à lista de marcas</a></p>";
echo "<p><a href='index.php?page=editar-marca&id_marca=" . $id . "'>Voltar à edição</a></p>";
?>