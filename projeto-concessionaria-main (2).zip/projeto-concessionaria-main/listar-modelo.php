<h1>Listar Modelo</h1>
<?php
require_once("config.php");
// Buscar modelos junto com o nome da marca
$sql = "SELECT 
            mo.*,
            ma.nome_marca
        FROM modelo mo
        LEFT JOIN marca ma ON ma.id_marca = mo.marca_id_marca
        ORDER BY mo.id_modelo";

$result = $conn->query($sql);
if ($result->num_rows > 0) {
    echo "<table border='1'>";
    echo "<tr>";
    echo "<th>ID</th>";
    echo "<th>Nome</th>";
    echo "<th>Cor</th>";
    echo "<th>Ano</th>";
    echo "<th>Tipo</th>";
    echo "<th>Marca</th>";
    echo "<th>Ações</th>";
    echo "</tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>".$row['id_modelo']."</td>";
        echo "<td>".$row['nome_modelo']."</td>";
        echo "<td>".$row['cor_modelo']."</td>";
        echo "<td>".$row['ano_modelo']."</td>";
        echo "<td>".$row['tipo_modelo']."</td>";
        echo "<td>".($row['nome_marca'] ?? 'Sem marca')."</td>";

        echo "<td>";
        echo "<a href='index.php?page=editar-modelo&id_modelo=".$row['id_modelo']."'>Editar</a> | ";
        echo "<a href='index.php?page=excluir-modelo&id_modelo=".$row['id_modelo']."' onclick=\"return confirm('Tem certeza que deseja excluir este modelo?');\">Excluir</a>";
        echo "</td>";

        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>Nenhum modelo cadastrado.</p>";
}
?>