<h1>Editar Venda</h1>
<?php
require_once("config.php");
$id = $_GET['id_venda'] ?? 0;
$id = (int)$id;
if ($id <= 0) {
    echo "<p>ID de venda inválido.</p>";
    exit;
}
// Buscar venda
$sql = "SELECT * FROM venda WHERE id_venda = $id";
$resVenda = $conn->query($sql);
if (!$resVenda || $resVenda->num_rows != 1) {
    echo "<p>Venda não encontrada.</p>";
    exit;
}
$venda = $resVenda->fetch_assoc();
// Buscar listas para selects
$sqlCli = "SELECT id_cliente, nome_cliente FROM cliente ORDER BY nome_cliente";
$resCli = $conn->query($sqlCli);
$sqlFunc = "SELECT id_funcionario, nome_funcionario FROM funcionario ORDER BY nome_funcionario";
$resFunc = $conn->query($sqlFunc);
$sqlMod = "SELECT id_modelo, nome_modelo FROM modelo ORDER BY nome_modelo";
$resMod = $conn->query($sqlMod);
?>
<form method="POST" action="index.php?page=atualizar-venda">
  <input type="hidden" name="id_venda" value="<?php echo $venda['id_venda']; ?>">
  <label>Data da Venda:</label><br>
  <input type="date" name="data_venda" value="<?php echo $venda['data_venda']; ?>"><br><br>

  <label>Valor da Venda:</label><br>
  <input type="number" step="0.01" name="valor_venda" value="<?php echo $venda['valor_venda']; ?>"><br><br>
  <label>Cliente:</label><br>
  <select name="cliente_id_cliente">
    <?php
    while ($c = $resCli->fetch_assoc()) {
        $sel = ($c['id_cliente'] == $venda['cliente_id_cliente']) ? "selected" : "";
        echo "<option value='".$c['id_cliente']."' $sel>".$c['nome_cliente']."</option>";
    }
    ?>
  </select><br><br>
  <label>Funcionário:</label><br>
  <select name="funcionario_id_funcionario">
    <?php
    while ($f = $resFunc->fetch_assoc()) {
        $sel = ($f['id_funcionario'] == $venda['funcionario_id_funcionario']) ? "selected" : "";
        echo "<option value='".$f['id_funcionario']."' $sel>".$f['nome_funcionario']."</option>";
    }
    ?>
  </select><br><br>
  <label>Modelo:</label><br>
  <select name="modelo_id_modelo">
    <?php
    while ($m = $resMod->fetch_assoc()) {
        $sel = ($m['id_modelo'] == $venda['modelo_id_modelo']) ? "selected" : "";
        echo "<option value='".$m['id_modelo']."' $sel>".$m['nome_modelo']."</option>";
    }
    ?>
  </select><br><br>
  <button type="submit">Salvar Alterações</button>
</form>