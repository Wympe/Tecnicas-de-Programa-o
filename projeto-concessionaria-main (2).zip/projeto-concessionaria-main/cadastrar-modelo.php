<h1>Cadastrar Modelo</h1>
<?php
require_once("config.php");
// Buscar as marcas existentes para o select
$sqlMarcas = "SELECT id_marca, nome_marca FROM marca ORDER BY nome_marca";
$resultMarcas = $conn->query($sqlMarcas);
if ($resultMarcas->num_rows == 0) {
    echo "<p>Você precisa cadastrar pelo menos uma marca antes de cadastrar modelos.</p>";
    echo "<p><a href='index.php?page=cadastrar-marca'>Cadastrar marca</a></p>";
    exit;
}
?>
<form method="POST" action="index.php?page=salvar-modelo">
  <label>Nome do Modelo:</label><br>
  <input type="text" name="nome_modelo"><br><br>

  <label>Cor:</label><br>
  <input type="text" name="cor_modelo"><br><br>

  <label>Ano:</label><br>
  <input type="number" name="ano_modelo"><br><br>

  <label>Tipo (sedan, hatch, SUV...):</label><br>
  <input type="text" name="tipo_modelo"><br><br>

  <label>Marca:</label><br>
  <select name="marca_id_marca">
    <?php
    while ($m = $resultMarcas->fetch_assoc()) {
        echo "<option value='".$m['id_marca']."'>".$m['nome_marca']."</option>";
    }
    ?>
  </select><br><br>
  <button type="submit">Salvar Modelo</button>
</form>