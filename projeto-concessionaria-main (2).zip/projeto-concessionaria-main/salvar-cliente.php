<h1>Resultado do cadastro de cliente</h1>
<?php
//Conecta com o banco de dados
require_once("config.php");
//Puxar os dados do formulário
$nome = $_POST['nome_cliente'];
$cpf = $_POST['cpf_cliente'];
$email = $_POST['email_cliente'];
$telefone = $_POST['telefone_cliente'];
$endereco = $_POST['endereco_cliente'];
$dt_nasc = $_POST['dt_nasc_cliente'];
//Montar o comando SQL para inserir os dados
$sql = "INSERT INTO cliente(
  nome_cliente,
  cpf_cliente,
  email_cliente,
  telefone_cliente,
  endereco_cliente,
  dt_nasc_cliente
  )VALUES(
  '$nome',
  '$cpf',
  '$email',
  '$telefone',
  '$endereco',
  '$dt_nasc'
  )";
//Executar o comando no banco
if($conn->query($sql)){
  echo "<p><strong>Cliente cadastrado com sucesso no banco!</strong></p>";
} else {
  echo "<p><strong>Erro ao cadastrar no banco:</strong>" . $conn->error . "</p>";
}
//Mostrar os dados na tela
echo "<p>Nome: $nome</p>";
echo "<p>CPF: $cpf</p>";
echo "<p>Email: $email</p>";
echo "<p>Telefone: $telefone</p>";
echo "<p>Endereço: $endereco</p>";
echo "<p>Data de Nascimento: $dt_nasc</p>";
//Ver o $_POST bruto, só pra poder ver o formato
echo "<hr>";
echo "<pre>";
print_r($_POST);
echo "</pre>";
?>
<!-- Link para voltar ao formulário -->
<p><a href="index.php?page=cadastrar-cliente">Voltar ao formulário</a></p>