<h1>Listar Cliente</h1>
<?php
// Conecta com o banco de dados
require_once("config.php");
// Montar o comando SQL para buscar todos os clientes
$sql = "SELECT * FROM cliente";
// Executar o comando no banco
$result = $conn->query($sql);
// Verificar se retornou algum resultado
if ($result->num_rows > 0) {
    echo "<table border='1'>";
    echo "<tr>";
    echo "<th>ID</th>";
    echo "<th>Nome</th>";
    echo "<th>CPF</th>";
    echo "<th>Email</th>";
    echo "<th>Telefone</th>";
    echo "<th>Ações</th>";
    echo "</tr>";
    // Percorrer cada linha de resultado
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['id_cliente'] . "</td>";
        echo "<td>" . $row['nome_cliente'] . "</td>";
        echo "<td>" . $row['cpf_cliente'] . "</td>";
        echo "<td>" . $row['email_cliente'] . "</td>";
        echo "<td>" . $row['telefone_cliente'] . "</td>";
        // Coluna de ações: Editar e Excluir
        echo "<td>";
        echo "<a href='index.php?page=editar-cliente&id_cliente=" . $row['id_cliente'] . "'>Editar</a> | ";
        echo "<a href='index.php?page=excluir-cliente&id_cliente=" . $row['id_cliente'] . "' onclick=\"return confirm('Tem certeza que deseja excluir este cliente?');\">Excluir</a>";
        echo "</td>";

        echo "</tr>";
    }
    // Fechar a tabela
    echo "</table>";
} else {
    echo "<p>Nenhum cliente encontrado.</p>";
}
?>
