<h1>Editar Modelo</h1>
<?php
require_once("config.php");
// Pegar ID do modelo
$id = $_GET['id_modelo'] ?? 0;
$id = (int)$id;
if ($id <= 0) {
    echo "<p>ID de modelo inválido.</p>";
    exit;
}
// Buscar dados do modelo
$sql = "SELECT * FROM modelo WHERE id_modelo = $id";
$result = $conn->query($sql);
if (!$result || $result->num_rows != 1) {
    echo "<p>Modelo não encontrado.</p>";
    exit;
}
$modelo = $result->fetch_assoc();
// Buscar marcas para o select
$sqlMarcas = "SELECT id_marca, nome_marca FROM marca ORDER BY nome_marca";
$resultMarcas = $conn->query($sqlMarcas);
?>
<form method="POST" action="index.php?page=atualizar-modelo">
  <input type="hidden" name="id_modelo" value="<?php echo $modelo['id_modelo']; ?>">

  <label>Nome do Modelo:</label><br>
  <input type="text" name="nome_modelo" value="<?php echo $modelo['nome_modelo']; ?>"><br><br>

  <label>Cor:</label><br>
  <input type="text" name="cor_modelo" value="<?php echo $modelo['cor_modelo']; ?>"><br><br>

  <label>Ano:</label><br>
  <input type="number" name="ano_modelo" value="<?php echo $modelo['ano_modelo']; ?>"><br><br>

  <label>Tipo:</label><br>
  <input type="text" name="tipo_modelo" value="<?php echo $modelo['tipo_modelo']; ?>"><br><br>

  <label>Marca:</label><br>
  <select name="marca_id_marca">
    <?php
    while ($m = $resultMarcas->fetch_assoc()) {
        $selected = ($m['id_marca'] == $modelo['marca_id_marca']) ? "selected" : "";
        echo "<option value='".$m['id_marca']."' $selected>".$m['nome_marca']."</option>";
    }
    ?>
  </select><br><br>
  <button type="submit">Salvar Alterações</button>
</form>