<h1>Atualizar Funcionário</h1>
<?php
// Conecta com o banco de dados
require_once("config.php");
// Pegar dados do POST
$id       = isset($_POST['id_funcionario']) ? (int)$_POST['id_funcionario'] : 0;
$nome     = $_POST['nome_funcionario']      ?? '';
$telefone = $_POST['telefone_funcionario']  ?? '';
$email    = $_POST['email_funcionario']     ?? '';
if ($id <= 0) {
    echo "<p>ID de funcionário inválido.</p>";
    exit;
}
// Montar UPDATE
$sql = "UPDATE funcionario SET
            nome_funcionario     = '$nome',
            telefone_funcionario = '$telefone',
            email_funcionario    = '$email'
        WHERE id_funcionario = $id";

// Executar
if ($conn->query($sql)) {
    echo "<p><strong>Funcionário atualizado com sucesso!</strong></p>";
} else {
    echo "<p><strong>Erro ao atualizar funcionário:</strong> " . $conn->error . "</p>";
}
// Resumo
echo "<hr>";
echo "<p>Nome: $nome</p>";
echo "<p>Telefone: $telefone</p>";
echo "<p>Email: $email</p>";
// Links
echo "<p><a href='index.php?page=listar-funcionario'>Voltar à lista de funcionários</a></p>";
echo "<p><a href='index.php?page=editar-funcionario&id_funcionario=" . $id . "'>Voltar à edição</a></p>";
?>