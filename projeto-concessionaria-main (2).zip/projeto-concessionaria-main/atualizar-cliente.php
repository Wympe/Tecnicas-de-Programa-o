<h1>Atualizar Cliente</h1>
<?php
// Conecta com o banco de dados
require_once("config.php");
// Pegar os dados enviados pelo formulário
$id       = isset($_POST['id_cliente']) ? (int)$_POST['id_cliente'] : 0;
$nome     = $_POST['nome_cliente']      ?? '';
$cpf      = $_POST['cpf_cliente']       ?? '';
$email    = $_POST['email_cliente']     ?? '';
$telefone = $_POST['telefone_cliente']  ?? '';
$endereco = $_POST['endereco_cliente']  ?? '';
$dt_nasc  = $_POST['dt_nasc_cliente']   ?? '';
// Verificar se o ID é válido
if ($id <= 0) {
    echo "<p>ID de cliente inválido.</p>";
    exit;
}
// Montar o comando SQL para atualizar os dados do cliente
$sql = "UPDATE cliente SET
            nome_cliente     = '$nome',
            cpf_cliente      = '$cpf',
            email_cliente    = '$email',
            telefone_cliente = '$telefone',
            endereco_cliente = '$endereco',
            dt_nasc_cliente  = '$dt_nasc'
        WHERE id_cliente = $id";

// Executar o comando no banco
if ($conn->query($sql)) {
    echo "<p><strong>Cliente atualizado com sucesso no banco!</strong></p>";
} else {
    echo "<p><strong>Erro ao atualizar o cliente:</strong> " . $conn->error . "</p>";
}
// Mostrar um resumo dos dados enviados
echo "<hr>";
echo "<p>Nome: $nome</p>";
echo "<p>CPF: $cpf</p>";
echo "<p>Email: $email</p>";
echo "<p>Telefone: $telefone</p>";
echo "<p>Endereço: $endereco</p>";
echo "<p>Data de Nascimento: $dt_nasc</p>";
// Links de navegação
echo "<p><a href='index.php?page=listar-cliente'>Voltar à lista de clientes</a></p>";
echo "<p><a href='index.php?page=editar-cliente&id_cliente=" . $id . "'>Voltar à edição</a></p>";
?>
