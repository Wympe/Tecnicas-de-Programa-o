<h1>Atualizar Modelo</h1>
<?php
require_once("config.php");
$id    = isset($_POST['id_modelo']) ? (int)$_POST['id_modelo'] : 0;
$nome  = $_POST['nome_modelo']    ?? '';
$cor   = $_POST['cor_modelo']     ?? '';
$ano   = $_POST['ano_modelo']     ?? '';
$tipo  = $_POST['tipo_modelo']    ?? '';
$marca = $_POST['marca_id_marca'] ?? '';
$ano   = (int)$ano;
$marca = (int)$marca;
if ($id <= 0) {
    echo "<p>ID de modelo inválido.</p>";
    exit;
}
$sql = "UPDATE modelo SET
            nome_modelo   = '$nome',
            cor_modelo    = '$cor',
            ano_modelo    = $ano,
            tipo_modelo   = '$tipo',
            marca_id_marca = $marca
        WHERE id_modelo = $id";

if ($conn->query($sql)) {
    echo "<p><strong>Modelo atualizado com sucesso!</strong></p>";
} else {
    echo "<p><strong>Erro ao atualizar modelo:</strong> " . $conn->error . "</p>";
}
echo "<hr>";
echo "<p>Nome: $nome</p>";
echo "<p>Cor: $cor</p>";
echo "<p>Ano: $ano</p>";
echo "<p>Tipo: $tipo</p>";
echo "<p>ID da Marca: $marca</p>";
echo "<p><a href='index.php?page=listar-modelo'>Voltar à lista de modelos</a></p>";
echo "<p><a href='index.php?page=editar-modelo&id_modelo=".$id."'>Voltar à edição</a></p>";
?>