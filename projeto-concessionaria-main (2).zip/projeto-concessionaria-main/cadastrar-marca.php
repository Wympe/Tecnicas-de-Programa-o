<h1>Cadastrar Marca</h1>
<form method="POST" action="index.php?page=salvar-marca">
  <label>Nome da Marca:</label><br>
  <input type="text" name="nome_marca"><br><br>
  <button type="submit">Salvar Marca</button>
</form>