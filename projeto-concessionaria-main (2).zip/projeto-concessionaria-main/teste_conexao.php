<?php
require_once("config.php");

echo "Config carregado. Testando tabelas...<br>";

$sql = "SELECT * FROM cliente";
$result = $conn->query($sql);

if ($result) {
    echo "Tabelas encontradas:<br>";
    while ($row = $result->fetch_array()) {
        echo $row[0] . "<br>";
    }
} else {
    echo "Erro ao listar tabelas: " . $conn->error;
}
?>
