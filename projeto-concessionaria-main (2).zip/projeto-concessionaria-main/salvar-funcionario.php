<h1>Resultado do cadastro de funcionário</h1>
<?php
// Conecta com o banco de dados
require_once("config.php");
// Puxar os dados do formulário
$nome     = $_POST['nome_funcionario']      ?? '';
$telefone = $_POST['telefone_funcionario']  ?? '';
$email    = $_POST['email_funcionario']     ?? '';
// Montar o comando SQL para inserir os dados
$sql = "INSERT INTO funcionario (
            nome_funcionario,
            telefone_funcionario,
            email_funcionario
        ) VALUES (
            '$nome',
            '$telefone',
            '$email'
        )";
// Executar o comando no banco
if ($conn->query($sql)) {
    echo "<p><strong>Funcionário cadastrado com sucesso no banco!</strong></p>";
} else {
    echo "<p><strong>Erro ao cadastrar funcionário no banco:</strong> " . $conn->error . "</p>";
}
// Mostrar os dados na tela
echo "<hr>";
echo "<p>Nome: $nome</p>";
echo "<p>Telefone: $telefone</p>";
echo "<p>Email: $email</p>";
// Links
echo "<p><a href='index.php?page=cadastrar-funcionario'>Voltar ao formulário</a></p>";
echo "<p><a href='index.php?page=listar-funcionario'>Ir para lista de funcionários</a></p>";
?>