<h1>Listar Funcionário</h1>
<?php
// Conecta com o banco de dados
require_once("config.php");
// Montar o comando SQL para buscar todos os funcionários
$sql = "SELECT * FROM funcionario";
// Executar o comando no banco
$result = $conn->query($sql);
// Verificar se retornou algum resultado
if ($result->num_rows > 0) {
    echo "<table border='1'>";
    echo "<tr>";
    echo "<th>ID</th>";
    echo "<th>Nome</th>";
    echo "<th>Telefone</th>";
    echo "<th>Email</th>";
    echo "<th>Ações</th>";
    echo "</tr>";
    // Percorrer cada linha de resultado
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['id_funcionario']      . "</td>";
        echo "<td>" . $row['nome_funcionario']    . "</td>";
        echo "<td>" . $row['telefone_funcionario']. "</td>";
        echo "<td>" . $row['email_funcionario']   . "</td>";

        echo "<td>";
        echo "<a href='index.php?page=editar-funcionario&id_funcionario=" . $row['id_funcionario'] . "'>Editar</a> | ";
        echo "<a href='index.php?page=excluir-funcionario&id_funcionario=" . $row['id_funcionario'] . "' onclick=\"return confirm('Tem certeza que deseja excluir este funcionário?');\">Excluir</a>";
        echo "</td>";

        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>Nenhum funcionário encontrado.</p>";
}
?>