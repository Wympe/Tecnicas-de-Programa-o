<h1>Listar Venda</h1>
<?php
require_once("config.php");
// Buscar vendas com nome de cliente, funcionário e modelo
$sql = "SELECT 
            v.*,
            c.nome_cliente,
            f.nome_funcionario,
            m.nome_modelo
        FROM venda v
        LEFT JOIN cliente c ON c.id_cliente = v.cliente_id_cliente
        LEFT JOIN funcionario f ON f.id_funcionario = v.funcionario_id_funcionario
        LEFT JOIN modelo m ON m.id_modelo = v.modelo_id_modelo
        ORDER BY v.id_venda";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    echo "<table border='1'>";
    echo "<tr>";
    echo "<th>ID</th>";
    echo "<th>Data</th>";
    echo "<th>Valor</th>";
    echo "<th>Cliente</th>";
    echo "<th>Funcionário</th>";
    echo "<th>Modelo</th>";
    echo "<th>Ações</th>";
    echo "</tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>".$row['id_venda']."</td>";
        echo "<td>".$row['data_venda']."</td>";
        echo "<td>".$row['valor_venda']."</td>";
        echo "<td>".($row['nome_cliente']      ?? '—')."</td>";
        echo "<td>".($row['nome_funcionario']  ?? '—')."</td>";
        echo "<td>".($row['nome_modelo']       ?? '—')."</td>";

        echo "<td>";
        echo "<a href='index.php?page=editar-venda&id_venda=".$row['id_venda']."'>Editar</a> | ";
        echo "<a href='index.php?page=excluir-venda&id_venda=".$row['id_venda']."' onclick=\"return confirm('Tem certeza que deseja excluir esta venda?');\">Excluir</a>";
        echo "</td>";

        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>Nenhuma venda cadastrada.</p>";
}
?>