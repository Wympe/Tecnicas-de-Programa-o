<h1>Excluir Funcionário</h1>
<?php
// Conecta com o banco de dados
require_once("config.php");
// Pegar ID pela URL
$id = $_GET['id_funcionario'] ?? 0;
$id = (int)$id;
// Validar
if ($id <= 0) {
    echo "<p>ID de funcionário inválido.</p>";
    exit;
}
// DELETE
$sql = "DELETE FROM funcionario WHERE id_funcionario = $id";
if ($conn->query($sql)) {
    echo "<p><strong>Funcionário excluído com sucesso!</strong></p>";
} else {
    echo "<p><strong>Erro ao excluir funcionário:</strong> " . $conn->error . "</p>";
}
echo "<p><a href='index.php?page=listar-funcionario'>Voltar à lista de funcionários</a></p>";
?>