<h1>Resultado do cadastro de modelo</h1>
<?php
require_once("config.php");
// Pegar dados do formulário
$nome  = $_POST['nome_modelo']   ?? '';
$cor   = $_POST['cor_modelo']    ?? '';
$ano   = $_POST['ano_modelo']    ?? '';
$tipo  = $_POST['tipo_modelo']   ?? '';
$marca = $_POST['marca_id_marca']?? '';
$ano   = (int)$ano;
$marca = (int)$marca;
// Montar INSERT
$sql = "INSERT INTO modelo (
            nome_modelo,
            cor_modelo,
            ano_modelo,
            tipo_modelo,
            marca_id_marca
        ) VALUES (
            '$nome',
            '$cor',
            $ano,
            '$tipo',
            $marca
        )";

if ($conn->query($sql)) {
    echo "<p><strong>Modelo cadastrado com sucesso!</strong></p>";
} else {
    echo "<p><strong>Erro ao cadastrar modelo:</strong> " . $conn->error . "</p>";
}
echo "<hr>";
echo "<p>Nome: $nome</p>";
echo "<p>Cor: $cor</p>";
echo "<p>Ano: $ano</p>";
echo "<p>Tipo: $tipo</p>";
echo "<p>ID da Marca: $marca</p>";
echo "<p><a href='index.php?page=cadastrar-modelo'>Voltar ao formulário</a></p>";
echo "<p><a href='index.php?page=listar-modelo'>Ir para lista de modelos</a></p>";
?>