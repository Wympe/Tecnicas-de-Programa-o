<h1>Excluir Marca</h1>
<?php
require_once("config.php");
$id = $_GET['id_marca'] ?? 0;
$id = (int)$id;
if ($id <= 0) {
    echo "<p>ID de marca inválido.</p>";
    exit;
}
$sql = "DELETE FROM marca WHERE id_marca = $id";
if ($conn->query($sql)) {
    echo "<p><strong>Marca excluída com sucesso!</strong></p>";
} else {
    echo "<p><strong>Erro ao excluir marca:</strong> " . $conn->error . "</p>";
}
echo "<p><a href='index.php?page=listar-marca'>Voltar à lista de marcas</a></p>";
?>