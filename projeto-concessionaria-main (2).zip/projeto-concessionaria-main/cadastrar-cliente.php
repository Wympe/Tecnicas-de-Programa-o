<h1>Cadastrar Cliente</h1>
<form method="POST" action="index.php?page=salvar-cliente">
  <label>Nome do Cliente:</label><br>
  <input type="text" name="nome_cliente"><br><br>
  <label>CPF:</label><br>
  <input type="text" name="cpf_cliente"><br><br>
  <label>Email:</label><br>
  <input type="email" name="email_cliente"><br><br>
  <label>Telefone:</label><br>
  <input type="text" name="telefone_cliente"><br><br>
  <label>Endereço:</label><br>
  <input type="text" name="endereco_cliente"><br><br>
  <label>Data de nascimento:</label><br>
  <input type="date" name="dt_nasc_cliente"><br><br>
  <button type="submit">Salvar Cliente</button>
</form>