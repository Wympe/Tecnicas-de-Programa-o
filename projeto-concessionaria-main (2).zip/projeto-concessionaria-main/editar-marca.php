<h1>Editar Marca</h1>
<?php
require_once("config.php");
$id = $_GET['id_marca'] ?? 0;
$id = (int)$id;
if ($id > 0) {
    $sql = "SELECT * FROM marca WHERE id_marca = $id";
    $result = $conn->query($sql);

    if ($result && $result->num_rows == 1) {
        $marca = $result->fetch_assoc();
    } else {
        echo "<p>Marca não encontrada.</p>";
        exit;
    }
} else {
    echo "<p>ID de marca inválido.</p>";
    exit;
}
?>
<form method="POST" action="index.php?page=atualizar-marca">
  <input type="hidden" name="id_marca" value="<?php echo $marca['id_marca']; ?>">

  <label>Nome da Marca:</label><br>
  <input type="text" name="nome_marca" value="<?php echo $marca['nome_marca']; ?>"><br><br>
  <button type="submit">Salvar Alterações</button>
</form>