<h1>Editar Cliente</h1>
<?php
//Conecta com o banco de dados
require_once("config.php");
//Pegar o ID do cliente que veio pela URL (GET)
$id = $_GET['id_cliente'] ?? 0; // se não vier nada, vira 0
$id = (int)$id;
//Verificar se o ID é válido
if($id > 0){
  //Montar o SELECT de um cliente específico
  $sql = "SELECT * FROM cliente WHERE id_cliente = $id";
  //Executar o comando no banco
  $result = $conn->query($sql);
  //Verificar se encontrou exatamente 1 cliente
  if ($result && $result->num_rows == 1){
    //Pegar os dados do cliente em um array associativo
    $cliente = $result->fetch_assoc();
  } else{
    echo "<p>Cliente não encontrado.</p>";
    exit;
  }
} else{
  echo "<p>ID de cliente inválido.</p>";
  exit;
}
?>
<form method="POST" action="index.php?page=atualizar-cliente">
  <!-- Campo escondido com o ID do cliente -->
  <input type="hidden" name="id_cliente" value="<?php echo $cliente['id_cliente']; ?>">
  <label>Nome do Cliente:</label><br>
  <input type="text" name="nome_cliente" value="<?php echo $cliente['nome_cliente']; ?>"><br><br>
  <label>CPF:</label><br>
  <input type="text" name="cpf_cliente" value="<?php echo $cliente['cpf_cliente']; ?>"><br><br>
  <label>Email:</label><br>
  <input type="email" name="email_cliente" value="<?php echo $cliente['email_cliente']; ?>"><br><br>
  <label>Telefone:</label><br>
  <input type="text" name="telefone_cliente" value="<?php echo $cliente['telefone_cliente']; ?>"><br><br>
  <label>Endereço:</label><br>
  <input type="text" name="endereco_cliente" value="<?php echo $cliente['endereco_cliente']; ?>"><br><br>
  <label>Data de nascimento:</label><br>
  <input type="date" name="dt_nasc_cliente" value="<?php echo $cliente['dt_nasc_cliente']; ?>"><br><br>
  <button type="submit">Salvar Alterações</button>
</form>
