<h1>Excluir Modelo</h1>
<?php
require_once("config.php");
$id = $_GET['id_modelo'] ?? 0;
$id = (int)$id;
if ($id <= 0) {
    echo "<p>ID de modelo inválido.</p>";
    exit;
}
$sql = "DELETE FROM modelo WHERE id_modelo = $id";
if ($conn->query($sql)) {
    echo "<p><strong>Modelo excluído com sucesso!</strong></p>";
} else {
    echo "<p><strong>Erro ao excluir modelo:</strong> " . $conn->error . "</p>";
}
echo "<p><a href='index.php?page=listar-modelo'>Voltar à lista de modelos</a></p>";
?>