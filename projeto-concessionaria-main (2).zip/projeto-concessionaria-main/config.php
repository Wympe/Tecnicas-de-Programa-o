<?php
// Configurações do banco de dados (XAMPP padrão)
$host = "localhost";
$user = "root";
$pass = "";                    // em XAMPP normal fica vazio
$db   = "concessionaria2122m"; // MESMO nome do banco no phpMyAdmin

// Cria a conexão
$conn = new mysqli($host, $user, $pass, $db);

// Verifica se deu erro
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}
?>
