<h1>Cadastrar Funcionário</h1>

<form method="POST" action="index.php?page=salvar-funcionario">
  <label>Nome do Funcionário:</label><br>
  <input type="text" name="nome_funcionario"><br><br>
  <label>Telefone:</label><br>
  <input type="text" name="telefone_funcionario"><br><br>
  <label>Email:</label><br>
  <input type="email" name="email_funcionario"><br><br>
  <button type="submit">Salvar Funcionário</button>
</form>