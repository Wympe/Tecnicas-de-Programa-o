<h1>Excluir Venda</h1>
<?php
require_once("config.php");
$id = $_GET['id_venda'] ?? 0;
$id = (int)$id;
if ($id <= 0) {
    echo "<p>ID de venda inválido.</p>";
    exit;
}
$sql = "DELETE FROM venda WHERE id_venda = $id";
if ($conn->query($sql)) {
    echo "<p><strong>Venda excluída com sucesso!</strong></p>";
} else {
    echo "<p><strong>Erro ao excluir venda:</strong> " . $conn->error . "</p>";
}
echo "<p><a href='index.php?page=listar-venda'>Voltar à lista de vendas</a></p>";
?>