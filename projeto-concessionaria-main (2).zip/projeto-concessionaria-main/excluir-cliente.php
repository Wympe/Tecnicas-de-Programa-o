<h1>Excluir Cliente</h1>
<?php
// Conecta com o banco de dados
require_once("config.php");

// Pegar o ID do cliente que veio pela URL (GET)
$id = $_GET['id_cliente'] ?? 0;
$id = (int)$id;

// Verificar se o ID é válido
if ($id <= 0) {
    echo "<p>ID de cliente inválido.</p>";
    exit;
}

// Montar o comando SQL para excluir o cliente
$sql = "DELETE FROM cliente WHERE id_cliente = $id";

// Executar o comando no banco
if ($conn->query($sql)) {
    echo "<p><strong>Cliente excluído com sucesso!</strong></p>";
} else {
    echo "<p><strong>Erro ao excluir o cliente:</strong> " . $conn->error . "</p>";
}

// Link para voltar à lista
echo "<p><a href='index.php?page=listar-cliente'>Voltar à lista de clientes</a></p>";
?>
