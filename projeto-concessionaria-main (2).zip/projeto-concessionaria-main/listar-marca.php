<h1>Listar Marca</h1>
<?php
require_once("config.php");
$sql = "SELECT * FROM marca";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    echo "<table border='1'>";
    echo "<tr>";
    echo "<th>ID</th>";
    echo "<th>Nome da Marca</th>";
    echo "<th>Ações</th>";
    echo "</tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['id_marca'] . "</td>";
        echo "<td>" . $row['nome_marca'] . "</td>";
        echo "<td>";
        echo "<a href='index.php?page=editar-marca&id_marca=" . $row['id_marca'] . "'>Editar</a> | ";
        echo "<a href='index.php?page=excluir-marca&id_marca=" . $row['id_marca'] . "' onclick=\"return confirm('Tem certeza que deseja excluir esta marca?');\">Excluir</a>";
        echo "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>Nenhuma marca cadastrada.</p>";
}
?>