<h1>Atualizar Venda</h1>
<?php
require_once("config.php");
$id      = isset($_POST['id_venda']) ? (int)$_POST['id_venda'] : 0;
$data    = $_POST['data_venda']                  ?? '';
$valor   = $_POST['valor_venda']                 ?? '0';
$cliente = $_POST['cliente_id_cliente']          ?? '';
$func    = $_POST['funcionario_id_funcionario']  ?? '';
$modelo  = $_POST['modelo_id_modelo']            ?? '';
$valor   = (float)$valor;
$cliente = (int)$cliente;
$func    = (int)$func;
$modelo  = (int)$modelo;
if ($id <= 0) {
    echo "<p>ID de venda inválido.</p>";
    exit;
}
$sql = "UPDATE venda SET
            data_venda                 = '$data',
            valor_venda                = $valor,
            cliente_id_cliente         = $cliente,
            funcionario_id_funcionario = $func,
            modelo_id_modelo           = $modelo
        WHERE id_venda = $id";
if ($conn->query($sql)) {
    echo "<p><strong>Venda atualizada com sucesso!</strong></p>";
} else {
    echo "<p><strong>Erro ao atualizar venda:</strong> " . $conn->error . "</p>";
}
echo "<hr>";
echo "<p>Data: $data</p>";
echo "<p>Valor: $valor</p>";
echo "<p>ID Cliente: $cliente</p>";
echo "<p>ID Funcionário: $func</p>";
echo "<p>ID Modelo: $modelo</p>";
echo "<p><a href='index.php?page=listar-venda'>Voltar à lista de vendas</a></p>";
echo "<p><a href='index.php?page=editar-venda&id_venda=".$id."'>Voltar à edição</a></p>";
?>