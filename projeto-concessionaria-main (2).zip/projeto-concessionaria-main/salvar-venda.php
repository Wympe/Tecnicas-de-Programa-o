<h1>Resultado do cadastro de venda</h1>
<?php
require_once("config.php");
// Pegar dados do formulário
$data   = $_POST['data_venda']              ?? '';
$valor  = $_POST['valor_venda']             ?? '0';
$cliente = $_POST['cliente_id_cliente']     ?? '';
$func   = $_POST['funcionario_id_funcionario'] ?? '';
$modelo = $_POST['modelo_id_modelo']        ?? '';
$valor   = (float)$valor;
$cliente = (int)$cliente;
$func    = (int)$func;
$modelo  = (int)$modelo;
// Montar INSERT
$sql = "INSERT INTO venda (
            data_venda,
            valor_venda,
            cliente_id_cliente,
            funcionario_id_funcionario,
            modelo_id_modelo
        ) VALUES (
            '$data',
            $valor,
            $cliente,
            $func,
            $modelo
        )";
if ($conn->query($sql)) {
    echo "<p><strong>Venda cadastrada com sucesso!</strong></p>";
} else {
    echo "<p><strong>Erro ao cadastrar venda:</strong> " . $conn->error . "</p>";
}
echo "<hr>";
echo "<p>Data: $data</p>";
echo "<p>Valor: $valor</p>";
echo "<p>ID Cliente: $cliente</p>";
echo "<p>ID Funcionário: $func</p>";
echo "<p>ID Modelo: $modelo</p>";
echo "<p><a href='index.php?page=cadastrar-venda'>Voltar ao formulário</a></p>";
echo "<p><a href='index.php?page=listar-venda'>Ir para lista de vendas</a></p>";
?>