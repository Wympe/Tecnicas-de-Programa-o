<h1>Cadastrar Venda</h1>
<?php
require_once("config.php");
// Buscar clientes
$sqlCli = "SELECT id_cliente, nome_cliente FROM cliente ORDER BY nome_cliente";
$resCli = $conn->query($sqlCli);
// Buscar funcionários
$sqlFunc = "SELECT id_funcionario, nome_funcionario FROM funcionario ORDER BY nome_funcionario";
$resFunc = $conn->query($sqlFunc);
// Buscar modelos
$sqlMod = "SELECT id_modelo, nome_modelo FROM modelo ORDER BY nome_modelo";
$resMod = $conn->query($sqlMod);
// Verificações rápidas
if ($resCli->num_rows == 0) {
    echo "<p>Você precisa cadastrar pelo menos um cliente antes de registrar vendas.</p>";
    echo "<p><a href='index.php?page=cadastrar-cliente'>Cadastrar cliente</a></p>";
    exit;
}
if ($resFunc->num_rows == 0) {
    echo "<p>Você precisa cadastrar pelo menos um funcionário antes de registrar vendas.</p>";
    echo "<p><a href='index.php?page=cadastrar-funcionario'>Cadastrar funcionário</a></p>";
    exit;
}
if ($resMod->num_rows == 0) {
    echo "<p>Você precisa cadastrar pelo menos um modelo antes de registrar vendas.</p>";
    echo "<p><a href='index.php?page=cadastrar-modelo'>Cadastrar modelo</a></p>";
    exit;
}
?>
<form method="POST" action="index.php?page=salvar-venda">
  <label>Data da Venda:</label><br>
  <input type="date" name="data_venda"><br><br>

  <label>Valor da Venda:</label><br>
  <input type="number" step="0.01" name="valor_venda"><br><br>
  <label>Cliente:</label><br>
  <select name="cliente_id_cliente">
    <?php
    while ($c = $resCli->fetch_assoc()) {
        echo "<option value='".$c['id_cliente']."'>".$c['nome_cliente']."</option>";
    }
    ?>
  </select><br><br>
  <label>Funcionário:</label><br>
  <select name="funcionario_id_funcionario">
    <?php
    while ($f = $resFunc->fetch_assoc()) {
        echo "<option value='".$f['id_funcionario']."'>".$f['nome_funcionario']."</option>";
    }
    ?>
  </select><br><br>
  <label>Modelo:</label><br>
  <select name="modelo_id_modelo">
    <?php
    while ($m = $resMod->fetch_assoc()) {
        echo "<option value='".$m['id_modelo']."'>".$m['nome_modelo']."</option>";
    }
    ?>
  </select><br><br>
  <button type="submit">Salvar Venda</button>
</form>