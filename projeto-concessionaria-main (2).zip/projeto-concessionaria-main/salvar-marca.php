<h1>Resultado do cadastro de marca</h1>
<?php
// Conecta com o banco de dados
require_once("config.php");
// Puxa os dados do formulário
$nome = $_POST['nome_marca'] ?? '';
// Monta o INSERT
$sql = "INSERT INTO marca (nome_marca) VALUES ('$nome')";
// Executa
if ($conn->query($sql)) {
    echo "<p><strong>Marca cadastrada com sucesso!</strong></p>";
} else {
    echo "<p><strong>Erro ao cadastrar marca:</strong> " . $conn->error . "</p>";
}
// Mostra dados
echo "<hr>";
echo "<p>Nome da marca: $nome</p>";
// Links
echo "<p><a href='index.php?page=cadastrar-marca'>Voltar ao formulário</a></p>";
echo "<p><a href='index.php?page=listar-marca'>Ir para lista de marcas</a></p>";
?>