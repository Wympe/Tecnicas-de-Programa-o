<h1>Editar Funcionário</h1>
<?php
// Conecta com o banco de dados
require_once("config.php");
// Pegar o ID do funcionário pela URL (GET)
$id = $_GET['id_funcionario'] ?? 0;
$id = (int)$id;
// Verificar se o ID é válido
if ($id > 0) {
    // Buscar o funcionário específico
    $sql = "SELECT * FROM funcionario WHERE id_funcionario = $id";
    $result = $conn->query($sql);

    if ($result && $result->num_rows == 1) {
        $func = $result->fetch_assoc();
    } else {
        echo "<p>Funcionário não encontrado.</p>";
        exit;
    }
} else {
    echo "<p>ID de funcionário inválido.</p>";
    exit;
}
?>
<form method="POST" action="index.php?page=atualizar-funcionario">
  <input type="hidden" name="id_funcionario" value="<?php echo $func['id_funcionario']; ?>">

  <label>Nome do Funcionário:</label><br>
  <input type="text" name="nome_funcionario" value="<?php echo $func['nome_funcionario']; ?>"><br><br>

  <label>Telefone:</label><br>
  <input type="text" name="telefone_funcionario" value="<?php echo $func['telefone_funcionario']; ?>"><br><br>
  <label>Email:</label><br>
  <input type="email" name="email_funcionario" value="<?php echo $func['email_funcionario']; ?>"><br><br>
  <button type="submit">Salvar Alterações</button>
</form>